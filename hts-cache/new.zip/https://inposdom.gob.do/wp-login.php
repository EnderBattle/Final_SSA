<!DOCTYPE html>
	<html lang="es">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Acceder < INPOSDOM — WordPress</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='dns-prefetch' href='//use.fontawesome.com' />
<link rel='dns-prefetch' href='//hcaptcha.com' />
<script src="https://inposdom.gob.do/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel='stylesheet' id='gtranslate-style-css' href='https://inposdom.gob.do/wp-content/plugins/gtranslate/gtranslate-style24.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://inposdom.gob.do/wp-includes/css/dashicons.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='buttons-css' href='https://inposdom.gob.do/wp-includes/css/buttons.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='forms-css' href='https://inposdom.gob.do/wp-admin/css/forms.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='l10n-css' href='https://inposdom.gob.do/wp-admin/css/l10n.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='login-css' href='https://inposdom.gob.do/wp-admin/css/login.min.css?ver=6.4.2' media='all' />
<link rel='stylesheet' id='logincust_styles-css' href='https://inposdom.gob.do/wp-content/plugins/login-customizer/src/Customizer/Panel/Assets/CSS/customizer.css?ver=6.4.2' media='all' />
<style id='logincust_styles-inline-css'>
body.login {background-color: #f0f0f1;}body.login div#login h1 a {background-image: url(" https://inposdom.gob.do/wp-content/uploads/2021/04/inposdomrecortado.png ");width: 300px;height: 150px;background-size: 300px 150px;padding-bottom: 0px;}#login form#loginform, #login form#registerform, #login form#lostpasswordform {height: 100%;padding: 30px 24px 45px 24px;border-radius: 10px;box-shadow: 0 1px 50px rgba(0,0,0,0.09);}div#login {width: 380px;}#login form .forgetmenot {display: none;}#login form#loginform .input, #login form#registerform .input, #login form#lostpasswordform .input {font-size: 20px;border-width: 0px;box-shadow: unset;}#login form#loginform label, #login form#registerform label, #login form#lostpasswordform label {}#login form#loginform .forgetmenot label, #login form#registerform .forgetmenot label, #login form#lostpasswordform .forgetmenot label {}#login form .submit .button {height: auto;background-color: #ed2431;width: 100%;height: 40px;padding: 0px 12px 2px 12px;border-width: 0px;text-shadow: 0 -1px 1px #000000,1px 0 1px #000000,0 1px 1px #000000,-1px 0 1px #000000;}#login form .submit .button:hover, #login form .submit .button:focus {background-color: #1b315d;}#login #backtoblog {display: none;}.login #nav, .login #nav a, .login #backtoblog a {font-size: 11px;}.login #nav, .login #nav a, .login #backtoblog a, .login .privacy-policy-page-link a {color: #262626;}.login #backtoblog a:hover, .login #nav a:hover, .login .privacy-policy-page-link a:hover {color: #303030;}/* Custom CSS for Material Template */
#login form#loginform .input,
#login form#registerform .input,
#login form#lostpasswordform .input {
	border-bottom: 1px solid #d2d2d2;
}

.bar {
	position: relative;
	display: block;
	width: 100%;
}

.bar:before, .bar:after {
	content: "";
	height: 2px; 
	width: 0;
	bottom: 15px; 
	position: absolute;
	background: #e91e63; 
	transition: all 0.2s ease;
}

.bar:before { left: 50%; }

.bar:after { right: 50%; }

input:focus ~ .bar:before, input:focus ~ .bar:after { width: 50%; }

.login #nav, .login #nav a, .login #backtoblog a {
    font-size: 11px;
		margin-top: 0px!important;
}

.login #login_error, .login .message, .login .success {
    border-left: 4px solid #72aee6;
    padding: 12px;
    margin-left: 0;
    margin-bottom: -15px;
		margin-top: -15px;
    background-color: #fff;
    box-shadow: 0 1px 1px 0 rgb(0 0 0 / 10%);
}

#reg_passmail{
	font-size: 12px!important;
}
</style>
<link rel='stylesheet' id='font-awesome-official-css' href='https://use.fontawesome.com/releases/v5.15.3/css/all.css' media='all' integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous" />
<link rel='stylesheet' id='font-awesome-official-v4shim-css' href='https://use.fontawesome.com/releases/v5.15.3/css/v4-shims.css' media='all' integrity="sha384-C2B+KlPW+WkR0Ld9loR1x3cXp7asA0iGVodhCoJ4hwrWm/d9qKS59BGisq+2Y0/D" crossorigin="anonymous" />
<style id='font-awesome-official-v4shim-inline-css'>
@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.eot"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-brands-400.svg#fontawesome") format("svg");
}

@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.eot"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-solid-900.svg#fontawesome") format("svg");
}

@font-face {
font-family: "FontAwesome";
font-display: block;
src: url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.eot"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.eot?#iefix") format("embedded-opentype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.woff2") format("woff2"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.woff") format("woff"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.ttf") format("truetype"),
		url("https://use.fontawesome.com/releases/v5.15.3/webfonts/fa-regular-400.svg#fontawesome") format("svg");
unicode-range: U+F004-F005,U+F007,U+F017,U+F022,U+F024,U+F02E,U+F03E,U+F044,U+F057-F059,U+F06E,U+F070,U+F075,U+F07B-F07C,U+F080,U+F086,U+F089,U+F094,U+F09D,U+F0A0,U+F0A4-F0A7,U+F0C5,U+F0C7-F0C8,U+F0E0,U+F0EB,U+F0F3,U+F0F8,U+F0FE,U+F111,U+F118-F11A,U+F11C,U+F133,U+F144,U+F146,U+F14A,U+F14D-F14E,U+F150-F152,U+F15B-F15C,U+F164-F165,U+F185-F186,U+F191-F192,U+F1AD,U+F1C1-F1C9,U+F1CD,U+F1D8,U+F1E3,U+F1EA,U+F1F6,U+F1F9,U+F20A,U+F247-F249,U+F24D,U+F254-F25B,U+F25D,U+F267,U+F271-F274,U+F279,U+F28B,U+F28D,U+F2B5-F2B6,U+F2B9,U+F2BB,U+F2BD,U+F2C1-F2C2,U+F2D0,U+F2D2,U+F2DC,U+F2ED,U+F328,U+F358-F35B,U+F3A5,U+F3D1,U+F410,U+F4AD;
}
</style>
<meta name="generator" content="Site Kit by Google 1.50.0" />		<style>
			div.wpforms-container-full .wpforms-form .h-captcha,
			#wpforo #wpforo-wrap div .h-captcha,
			.h-captcha {
				position: relative;
				display: block;
				margin-bottom: 2rem;
				padding: 0;
				clear: both;
			}
			#af-wrapper div.editor-row.editor-row-hcaptcha {
				display: flex;
				flex-direction: row-reverse;
			}
			#af-wrapper div.editor-row.editor-row-hcaptcha .h-captcha {
				margin-bottom: 0;
			}
			form.wpsc-create-ticket .h-captcha {
				margin: 0 15px 15px 15px;
			}
			.gform_previous_button + .h-captcha {
				margin-top: 2rem;
			}
			#wpforo #wpforo-wrap.wpft-topic div .h-captcha,
			#wpforo #wpforo-wrap.wpft-forum div .h-captcha {
				margin: 0 -20px;
			}
			.wpdm-button-area + .h-captcha {
				margin-bottom: 1rem;
			}
			.w3eden .btn-primary {
				background-color: var(--color-primary) !important;
				color: #fff !important;
			}
			div.wpforms-container-full .wpforms-form .h-captcha[data-size="normal"],
			.h-captcha[data-size="normal"] {
				width: 303px;
				height: 78px;
			}
			div.wpforms-container-full .wpforms-form .h-captcha[data-size="compact"],
			.h-captcha[data-size="compact"] {
				width: 164px;
				height: 144px;
			}
			div.wpforms-container-full .wpforms-form .h-captcha[data-size="invisible"],
			.h-captcha[data-size="invisible"] {
				display: none;
			}
			.h-captcha::before {
				content: '';
				display: block;
				position: absolute;
				top: 0;
				left: 0;
				background: url(https://inposdom.gob.do/wp-content/plugins/hcaptcha-for-forms-and-more/assets/images/hcaptcha-div-logo.svg) no-repeat;
				border: 1px solid transparent;
				border-radius: 4px;
			}
			.h-captcha[data-size="normal"]::before {
				width: 300px;
				height: 74px;
				background-position: 94% 27%;
			}
			.h-captcha[data-size="compact"]::before {
				width: 156px;
				height: 136px;
				background-position: 50% 77%;
			}
			.h-captcha[data-theme="light"]::before {
				background-color: #fafafa;
				border: 1px solid #e0e0e0;
			}
			.h-captcha[data-theme="dark"]::before {
				background-color: #333;
				border: 1px solid #f5f5f5;
			}
			.h-captcha[data-size="invisible"]::before {
				display: none;
			}
			div.wpforms-container-full .wpforms-form .h-captcha iframe,
			.h-captcha iframe {
				position: relative;
			}
			span[data-name="hcap-cf7"] .h-captcha {
				margin-bottom: 0;
			}
			span[data-name="hcap-cf7"] ~ input[type="submit"] {
				margin-top: 2rem;
			}
			.elementor-field-type-hcaptcha .elementor-field {
				background: transparent !important;
			}
			.elementor-field-type-hcaptcha .h-captcha {
				margin-bottom: unset;
			}
			div[style*="z-index: 2147483647"] div[style*="border-width: 11px"][style*="position: absolute"][style*="pointer-events: none"] {
				border-style: none;
			}
		</style>
				<style>
			@media (max-width: 349px) {
				.h-captcha {
					display: flex;
					justify-content: center;
				}
			}
			@media (min-width: 350px) {
				#login {
					width: 350px;
				}
			}
		</style>
			<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="https://inposdom.gob.do/wp-content/uploads/2022/02/cropped-icono22-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://inposdom.gob.do/wp-content/uploads/2022/02/cropped-icono22-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://inposdom.gob.do/wp-content/uploads/2022/02/cropped-icono22-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://inposdom.gob.do/wp-content/uploads/2022/02/cropped-icono22-270x270.jpg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui  locale-es-es">
	<script>
document.body.className = document.body.className.replace('no-js','js');
</script>

		<div id="login">
		<h1><a href="https://inposdom.gob.do/">INPOSDOM</a></h1>
	
		<form name="loginform" id="loginform" action="https://inposdom.gob.do/wp-login.php" method="post">
			<p>
				<label for="user_login">Nombre de usuario o correo electrónico</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">Contraseña</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Mostrar la contraseña">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
					<div
			class="h-captcha"
			data-sitekey="0ac76f39-3533-432c-b510-0bb103f28c6c"
			data-theme="light"
			data-size="normal"
						data-auto="false">
		</div>
		<input type="hidden" id="hcaptcha_login_nonce" name="hcaptcha_login_nonce" value="ccd9ab617d" /><input type="hidden" name="_wp_http_referer" value="/wp-login.php" />			<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">Recuérdame</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Acceder" />
									<input type="hidden" name="redirect_to" value="https://inposdom.gob.do/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://inposdom.gob.do/wp-login.php?action=lostpassword">¿Has olvidado tu contraseña?</a>			</p>
			<script>
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
</script>
		<p id="backtoblog">
			<a href="https://inposdom.gob.do/">&larr; Ir a INPOSDOM</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" action="" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							Idioma						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="es_ES" lang="es" selected='selected' data-installed="1">Español</option></select>
					
					
					
						<input type="submit" class="button" value="Cambiar">

					</form>
				</div>
				<script>
// Custom JS for Material Template
function insertAfter( newNode, referenceNode ) {
    referenceNode.parentNode.insertBefore( newNode, referenceNode.nextSibling );
}

var inputFields = document.querySelectorAll( ".input" );

inputFields.forEach( ( field ) => {
	var bar = document.createElement("span");
		bar.setAttribute( "class", "bar" );
	insertAfter( bar, field );
});
</script>
		<script>
			( () => {
				'use strict';

				let loaded = false,
					scrolled = false,
					timerId;

				function load() {
					if ( loaded ) {
						return;
					}

					loaded = true;
					clearTimeout( timerId );

					window.removeEventListener( 'touchstart', load );
					document.removeEventListener( 'mouseenter', load );
					document.removeEventListener( 'click', load );
					window.removeEventListener( 'load', delayedLoad );

							const t = document.getElementsByTagName( 'script' )[0];
		const s = document.createElement('script');
		s.type  = 'text/javascript';
		s['src'] = 'https://js.hcaptcha.com/1/api.js?onload=hCaptchaOnLoad&render=explicit&hl=es';
		s.async = true;
		t.parentNode.insertBefore( s, t );
						}

				function scrollHandler() {
					if ( ! scrolled ) {
						// Ignore first scroll event, which can be on page load.
						scrolled = true;
						return;
					}

					window.removeEventListener( 'scroll', scrollHandler );
					load();
				}

				function delayedLoad() {
					window.addEventListener( 'scroll', scrollHandler );
					const delay = -100;

					if ( delay >= 0 ) {
						setTimeout( load, delay );
					}
				}

				window.addEventListener( 'touchstart', load );
				document.addEventListener( 'mouseenter', load );
				document.addEventListener( 'click', load );
				window.addEventListener( 'load', delayedLoad );
			} )();
		</script>

		<script id="zxcvbn-async-js-extra">
var _zxcvbnSettings = {"src":"https:\/\/inposdom.gob.do\/wp-includes\/js\/zxcvbn.min.js"};
</script>
<script src="https://inposdom.gob.do/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/dist/vendor/wp-polyfill-inert.min.js?ver=3.1.2" id="wp-polyfill-inert-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.14.0" id="regenerator-runtime-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0" id="wp-polyfill-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/dist/hooks.min.js?ver=c6aec9a8d4e5a5d543a1" id="wp-hooks-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/dist/i18n.min.js?ver=7701b0c3857f914212ef" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script id="password-strength-meter-js-extra">
var pwsL10n = {"unknown":"Fortaleza de la contrase\u00f1a desconocida","short":"Muy d\u00e9bil","bad":"D\u00e9bil","good":"Medio","strong":"Fuerte","mismatch":"No coinciden"};
</script>
<script id="password-strength-meter-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2023-11-09 11:37:23+0000","generator":"GlotPress\/4.0.0-alpha.11","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"es"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["\u00a1%1$s est\u00e1 obsoleto desde la versi\u00f3n %2$s! Usa %3$s en su lugar. Por favor, plant\u00e9ate escribir un c\u00f3digo m\u00e1s inclusivo."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
</script>
<script src="https://inposdom.gob.do/wp-admin/js/password-strength-meter.min.js?ver=6.4.2" id="password-strength-meter-js"></script>
<script src="https://inposdom.gob.do/wp-includes/js/underscore.min.js?ver=1.13.4" id="underscore-js"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src="https://inposdom.gob.do/wp-includes/js/wp-util.min.js?ver=6.4.2" id="wp-util-js"></script>
<script id="user-profile-js-extra">
var userProfileL10n = {"user_id":"0","nonce":"a34a8736c0"};
</script>
<script id="user-profile-js-translations">
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2023-11-09 11:37:23+0000","generator":"GlotPress\/4.0.0-alpha.11","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=2; plural=n != 1;","lang":"es"},"Your new password has not been saved.":["No ha sido guardada tu nueva contrase\u00f1a."],"Hide":["Ocultar"],"Show":["Mostrar"],"Confirm use of weak password":["Confirma el uso de una contrase\u00f1a d\u00e9bil."],"Hide password":["Ocultar la contrase\u00f1a"],"Show password":["Mostrar la contrase\u00f1a"]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
</script>
<script src="https://inposdom.gob.do/wp-admin/js/user-profile.min.js?ver=6.4.2" id="user-profile-js"></script>
<script id="hcaptcha-js-extra">
var HCaptchaMainObject = {"params":""};
</script>
<script src="https://inposdom.gob.do/wp-content/plugins/hcaptcha-for-forms-and-more/assets/js/apps/hcaptcha.js?ver=2.7.0" id="hcaptcha-js"></script>
	</body>
	</html>
	